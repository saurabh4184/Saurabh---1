import 'package:frappe_app/views/base_viewmodel.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class ViewReviewsBottomSheetViewModel extends BaseViewModel {}
